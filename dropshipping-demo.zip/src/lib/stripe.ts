import Stripe from "stripe";

export function getStripeServer() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error(
      "STRIPE_SECRET_KEY is not defined. Add it to your .env file."
    );
  }
  return new Stripe(key, {
    apiVersion: "2025-03-31" as Stripe.LatestApiVersion,
    typescript: true,
  });
}


