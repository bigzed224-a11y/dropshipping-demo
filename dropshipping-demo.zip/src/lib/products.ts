export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  colors?: string[];
  features: string[];
}

export const products: Product[] = [
  {
    id: "1",
    name: "Premium Wireless Headphones",
    description: "Experience crystal-clear audio with our flagship noise-cancelling headphones. Featuring 40-hour battery life, memory foam ear cushions, and adaptive sound technology that adjusts to your environment. Perfect for music lovers, remote workers, and frequent travelers.",
    price: 89.99,
    originalPrice: 149.99,
    image: "https://picsum.photos/seed/headphones/800/800",
    category: "Electronics",
    rating: 4.8,
    reviewCount: 2347,
    inStock: true,
    colors: ["#1a1a2e", "#e8e8e8", "#c0392b"],
    features: ["Active Noise Cancellation", "40hr Battery Life", "Memory Foam Cushions", "Bluetooth 5.3", "Built-in Microphone"]
  },
  {
    id: "2",
    name: "Smart Fitness Watch Pro",
    description: "Your all-in-one health companion. Track your heart rate, sleep patterns, blood oxygen, and 50+ workout modes. Water-resistant to 50 meters with a vibrant AMOLED display that's always on. Get 14 days of battery life on a single charge.",
    price: 129.99,
    originalPrice: 199.99,
    image: "https://picsum.photos/seed/fitnesswatch/800/800",
    category: "Wearables",
    rating: 4.7,
    reviewCount: 1832,
    inStock: true,
    colors: ["#2c3e50", "#ecf0f1", "#e74c3c"],
    features: ["Heart Rate Monitor", "Sleep Tracking", "GPS Tracking", "50+ Workout Modes", "14-Day Battery"]
  },
  {
    id: "3",
    name: "Ultra-Light Laptop Backpack",
    description: "The perfect everyday carry for professionals and students. Crafted from water-resistant Oxford fabric with padded compartments for up to 17\" laptops. Features a hidden anti-theft pocket, USB charging port, and ergonomic shoulder straps for all-day comfort.",
    price: 49.99,
    originalPrice: 79.99,
    image: "https://picsum.photos/seed/backpack/800/800",
    category: "Accessories",
    rating: 4.6,
    reviewCount: 3120,
    inStock: true,
    colors: ["#2c3e50", "#34495e", "#7f8c8d"],
    features: ["Water-Resistant", "Fits 17\" Laptop", "USB Charging Port", "Anti-Theft Pocket", "Ergonomic Design"]
  },
  {
    id: "4",
    name: "Wireless Charging Station",
    description: "Charge your entire ecosystem at once. This 3-in-1 charging station powers your iPhone, AirPods, and Apple Watch simultaneously. With fast-charge capability (15W max) and a sleek, minimalist design that looks beautiful on any desk or nightstand.",
    price: 39.99,
    originalPrice: 59.99,
    image: "https://picsum.photos/seed/charger/800/800",
    category: "Electronics",
    rating: 4.5,
    reviewCount: 1567,
    inStock: true,
    features: ["3-in-1 Charging", "15W Fast Charge", "LED Indicator", "Overcharge Protection", "Non-Slip Base"]
  },
  {
    id: "5",
    name: "Portable Bluetooth Speaker",
    description: "Big sound that fits in your palm. This IPX7 waterproof speaker delivers 360° immersive audio with deep bass. With 24-hour playtime, a built-in power bank, and a rugged design that survives drops, it's the ultimate adventure companion.",
    price: 59.99,
    originalPrice: 89.99,
    image: "https://picsum.photos/seed/speaker/800/800",
    category: "Electronics",
    rating: 4.7,
    reviewCount: 2890,
    inStock: true,
    colors: ["#1a1a2e", "#e74c3c", "#2ecc71", "#3498db"],
    features: ["IPX7 Waterproof", "24hr Playtime", "360° Sound", "Built-in Power Bank", "Rugged Design"]
  },
  {
    id: "6",
    name: "Ergonomic Office Chair",
    description: "Upgrade your workspace with our best-selling ergonomic chair. Features adjustable lumbar support, 4D armrests, breathable mesh back, and a tilt-lock mechanism. Designed for 8+ hour workdays with premium materials that last for years.",
    price: 299.99,
    originalPrice: 449.99,
    image: "https://picsum.photos/seed/officechair/800/800",
    category: "Home Office",
    rating: 4.8,
    reviewCount: 4567,
    inStock: true,
    colors: ["#2c3e50", "#1a1a2e"],
    features: ["Adjustable Lumbar Support", "4D Armrests", "Breathable Mesh", "Tilt Lock", "400lbs Capacity"]
  },
  {
    id: "7",
    name: "Minimalist Desk Organizer",
    description: "Transform your cluttered desk into an organized workspace. This bamboo desk organizer features 8 compartments for your phone, pens, notes, and accessories. The natural bamboo finish adds warmth to any modern office aesthetic.",
    price: 34.99,
    originalPrice: 49.99,
    image: "https://picsum.photos/seed/deskorg/800/800",
    category: "Home Office",
    rating: 4.4,
    reviewCount: 892,
    inStock: true,
    features: ["8 Compartments", "Natural Bamboo", "Non-Slip Base", "Easy Assembly", "Eco-Friendly"]
  },
  {
    id: "8",
    name: "Smart Water Bottle",
    description: "Never forget to hydrate again. This smart water bottle tracks your water intake, glows to remind you to drink, and keeps your water cold for 24 hours or hot for 12. Syncs with your phone to monitor your hydration goals throughout the day.",
    price: 44.99,
    originalPrice: 69.99,
    image: "https://picsum.photos/seed/waterbottle/800/800",
    category: "Lifestyle",
    rating: 4.6,
    reviewCount: 1234,
    inStock: true,
    colors: ["#3498db", "#e74c3c", "#2ecc71", "#f39c12"],
    features: ["24hr Cold / 12hr Hot", "Smart Tracking", "LED Reminder", "App Sync", "BPA-Free"]
  },
  {
    id: "9",
    name: "LED Desk Lamp with Wireless Charger",
    description: "The ultimate desk lamp with 5 color temperatures, 7 brightness levels, and a built-in 15W wireless charging pad. The flexible gooseneck and memory function make it perfect for reading, working, or relaxing.",
    price: 69.99,
    originalPrice: 99.99,
    image: "https://picsum.photos/seed/desklamp/800/800",
    category: "Home Office",
    rating: 4.7,
    reviewCount: 2156,
    inStock: true,
    features: ["Wireless Charger Built-in", "5 Color Temps", "7 Brightness Levels", "Flexible Gooseneck", "Memory Function"]
  },
  {
    id: "10",
    name: "Premium Yoga Mat",
    description: "Practice with confidence on the most premium yoga mat available. Extra-thick 6mm cushioning protects your joints while the natural rubber surface provides unmatched grip — even during hot yoga. Comes with a carrying strap and lifetime warranty.",
    price: 79.99,
    originalPrice: 119.99,
    image: "https://picsum.photos/seed/yogamat/800/800",
    category: "Fitness",
    rating: 4.9,
    reviewCount: 3456,
    inStock: true,
    colors: ["#8e44ad", "#2ecc71", "#e74c3c", "#3498db"],
    features: ["6mm Extra Thick", "Natural Rubber", "Non-Slip Surface", "Carrying Strap", "Lifetime Warranty"]
  },
  {
    id: "11",
    name: "Noise-Canceling Sleep Mask",
    description: "Experience the deepest sleep of your life. This premium sleep mask features built-in Bluetooth speakers, ultra-soft memory foam padding, and complete blackout technology. Listen to your favorite sleep sounds without disturbing your partner.",
    price: 54.99,
    originalPrice: 79.99,
    image: "https://picsum.photos/seed/sleepmask/800/800",
    category: "Lifestyle",
    rating: 4.5,
    reviewCount: 1876,
    inStock: true,
    colors: ["#1a1a2e", "#2c3e50", "#e8e8e8"],
    features: ["Built-in Speakers", "Bluetooth 5.0", "Memory Foam", "Complete Blackout", "Washable Cover"]
  },
  {
    id: "12",
    name: "Mechanical Keyboard",
    description: "Type like never before with our hot-swappable mechanical keyboard. Features per-key RGB lighting, PBT double-shot keycaps, and your choice of Cherry MX switches. The aluminum frame and USB-C connectivity make this the last keyboard you'll ever buy.",
    price: 119.99,
    originalPrice: 169.99,
    image: "https://picsum.photos/seed/keyboard/800/800",
    category: "Electronics",
    rating: 4.8,
    reviewCount: 4567,
    inStock: true,
    features: ["Hot-Swappable Switches", "Per-Key RGB", "PBT Keycaps", "Aluminum Frame", "USB-C"]
  }
];

export const categories = [...new Set(products.map((p) => p.category))];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category === category);
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price);
}
