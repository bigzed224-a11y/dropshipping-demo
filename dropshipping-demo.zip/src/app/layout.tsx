import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import Header from "@/components/Header";
import CartSheet from "@/components/CartSheet";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "DropShop - Premium Dropshipping Store",
  description:
    "Discover premium products at unbeatable prices. Fast shipping, secure checkout, and exceptional quality guaranteed.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <CartProvider>
          <div className="flex min-h-screen flex-col bg-gradient-to-b from-gray-50 to-white">
            <Header />
            <main className="flex-1">{children}</main>
            <footer className="border-t border-gray-100 bg-white py-8">
              <div className="mx-auto max-w-7xl px-4 text-center text-sm text-gray-500">
                <p className="font-medium text-gray-700">
                  DropShop Demo Store
                </p>
                <p className="mt-1">
                  Built with Next.js + Stripe — for demonstration purposes only
                </p>
              </div>
            </footer>
          </div>
          <CartSheet />
          <Toaster position="top-right" richColors />
        </CartProvider>
      </body>
    </html>
  );
}
