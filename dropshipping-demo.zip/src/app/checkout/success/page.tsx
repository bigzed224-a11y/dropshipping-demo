"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { CheckCircle, Package, ArrowLeft, Sparkles } from "lucide-react";
import { useCart } from "@/context/CartContext";

export default function CheckoutSuccessPage() {
  const { clearCart, items } = useCart();
  const hasCleared = useRef(false);

  useEffect(() => {
    if (items.length > 0 && !hasCleared.current) {
      hasCleared.current = true;
      clearCart();
    }
  }, [items.length, clearCart]);

  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4 py-16">
      <div className="mx-auto max-w-lg text-center">
        {/* Success Animation */}
        <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-green-100 to-emerald-50 shadow-lg shadow-green-100">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-green-500 to-emerald-600 shadow-xl shadow-green-200">
            <CheckCircle className="h-8 w-8 text-white" />
          </div>
        </div>

        <h1 className="mt-8 text-3xl font-extrabold tracking-tight text-gray-900">
          Order Confirmed!
        </h1>
        <p className="mt-4 text-lg text-gray-600">
          Thank you for your purchase. Your order has been received and is being
          processed.
        </p>

        {/* Order Details Card */}
        <div className="mt-8 rounded-2xl border border-green-100 bg-gradient-to-br from-green-50 to-emerald-50 p-6 shadow-sm">
          <div className="flex items-center justify-center gap-2">
            <Package className="h-5 w-5 text-green-600" />
            <span className="text-sm font-semibold text-green-800">
              Order #DS-{Date.now().toString(36).toUpperCase()}
            </span>
          </div>
          <p className="mt-3 text-sm text-green-700">
            You will receive a confirmation email with your order details and
            tracking information shortly.
          </p>
        </div>

        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link
            href="/"
            className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 px-8 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200/50 transition-all duration-200 hover:from-indigo-600 hover:to-purple-700"
          >
            <ArrowLeft className="h-4 w-4 transition-transform duration-200 group-hover:-translate-x-1" />
            Continue Shopping
          </Link>
        </div>

        <div className="mt-6 flex items-center justify-center gap-1.5 text-xs text-gray-400">
          <Sparkles className="h-3 w-3" />
          Demo store — no real payment was processed
        </div>
      </div>
    </div>
  );
}
