"use client";

import { useState } from "react";
import { products, categories } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import HeroSection from "@/components/HeroSection";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [sortBy, setSortBy] = useState<string>("featured");

  const filteredProducts =
    activeCategory === "All"
      ? [...products]
      : products.filter((p) => p.category === activeCategory);

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      case "name":
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  return (
    <>
      <HeroSection />

      {/* Categories Section */}
      <section id="categories" className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Shop by{" "}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Category
              </span>
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              Browse our curated collections
            </p>
          </div>

          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            <button
              onClick={() => setActiveCategory("All")}
              className={`group relative overflow-hidden rounded-2xl border-2 p-6 text-left transition-all duration-200 ${
                activeCategory === "All"
                  ? "border-indigo-500 bg-gradient-to-br from-indigo-50 to-purple-50 shadow-md shadow-indigo-100"
                  : "border-gray-100 bg-white hover:border-indigo-200 hover:shadow-md"
              }`}
            >
              <p
                className={`text-lg font-bold ${
                  activeCategory === "All"
                    ? "text-indigo-600"
                    : "text-gray-900"
                }`}
              >
                All Products
              </p>
              <p className="mt-1 text-sm text-gray-500">
                {products.length} items
              </p>
            </button>
            {categories.map((category) => {
              const count = products.filter(
                (p) => p.category === category
              ).length;
              return (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`group relative overflow-hidden rounded-2xl border-2 p-6 text-left transition-all duration-200 ${
                    activeCategory === category
                      ? "border-indigo-500 bg-gradient-to-br from-indigo-50 to-purple-50 shadow-md shadow-indigo-100"
                      : "border-gray-100 bg-white hover:border-indigo-200 hover:shadow-md"
                  }`}
                >
                  <p
                    className={`text-lg font-bold ${
                      activeCategory === category
                        ? "text-indigo-600"
                        : "text-gray-900"
                    }`}
                  >
                    {category}
                  </p>
                  <p className="mt-1 text-sm text-gray-500">{count} items</p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 sm:py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                Featured{" "}
                <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Products
                </span>
              </h2>
              <p className="mt-2 text-lg text-gray-600">
                {activeCategory === "All"
                  ? "Discover our most popular items"
                  : `Browse ${activeCategory}`}
              </p>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-gray-700">
                Sort by:
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition-colors hover:border-indigo-200 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="name">Name A-Z</option>
              </select>
            </div>
          </div>

          {/* Product Grid */}
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {sortedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {sortedProducts.length === 0 && (
            <div className="py-20 text-center">
              <p className="text-lg text-gray-500">
                No products found in this category.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 to-purple-700 px-6 py-16 shadow-2xl sm:px-16 sm:py-24">
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -left-20 -top-20 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
              <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
            </div>
            <div className="relative mx-auto max-w-xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Stay in the Loop
              </h2>
              <p className="mt-4 text-lg text-indigo-100">
                Get exclusive deals and new product alerts delivered to your
                inbox.
              </p>
              <div className="mt-8 flex gap-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 rounded-xl border border-white/20 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-indigo-200 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-white/50"
                />
                <button className="rounded-xl bg-white px-6 py-3 text-sm font-semibold text-indigo-600 shadow-lg transition-all duration-200 hover:bg-indigo-50 active:scale-95">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
