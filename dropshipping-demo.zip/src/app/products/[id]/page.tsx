"use client";

import { useParams, notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import {
  ArrowLeft,
  ShoppingCart,
  Star,
  Check,
  Truck,
  Shield,
  RotateCcw,
  ChevronRight,
} from "lucide-react";
import { products, getProductById, formatPrice } from "@/lib/products";
import { useCart } from "@/context/CartContext";
import { Badge } from "@/components/ui/badge";
import ProductCard from "@/components/ProductCard";

export default function ProductDetailPage() {
  const params = useParams();
  const product = getProductById(params.id as string);
  const { addItem } = useCart();
  const [selectedColor, setSelectedColor] = useState<string | null>(null);

  if (!product) {
    notFound();
  }

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const discount = product.originalPrice
    ? Math.round(
        ((product.originalPrice - product.price) / product.originalPrice) * 100
      )
    : 0;

  return (
    <div className="min-h-screen bg-white">
      {/* Breadcrumb */}
      <div className="border-b border-gray-100 bg-gray-50/50">
        <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-indigo-600 transition-colors">
              Home
            </Link>
            <ChevronRight className="h-3.5 w-3.5" />
            <Link
              href="/#products"
              className="hover:text-indigo-600 transition-colors"
            >
              Products
            </Link>
            <ChevronRight className="h-3.5 w-3.5" />
            <span className="font-medium text-gray-900">{product.name}</span>
          </div>
        </div>
      </div>

      {/* Product Detail */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Image */}
          <div className="relative">
            <div className="relative aspect-square overflow-hidden rounded-3xl bg-gray-50 shadow-lg">
              <Image
                src={product.image}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
                priority
              />
              {discount > 0 && (
                <Badge className="absolute left-4 top-4 bg-gradient-to-r from-red-500 to-orange-500 px-3 py-1.5 text-sm font-bold text-white shadow-lg">
                  -{discount}% OFF
                </Badge>
              )}
            </div>

            {/* Thumbnail dots - different angles */}
            <div className="mt-4 flex gap-3">
              {[1, 2, 3, 4].map((i) => (
                <button
                  key={i}
                  className={`h-16 w-16 overflow-hidden rounded-xl border-2 transition-all ${
                    i === 1
                      ? "border-indigo-500 ring-2 ring-indigo-200"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="relative h-full w-full">
                    <Image
                      src={`https://picsum.photos/seed/${product.id}-view${i}/200/200`}
                      alt={`${product.name} view ${i}`}
                      fill
                      className="object-cover"
                      sizes="64px"
                    />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="flex flex-col gap-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-widest text-indigo-600">
                  {product.category}
                </span>
                {!product.inStock && (
                  <Badge variant="secondary" className="text-xs">
                    Out of Stock
                  </Badge>
                )}
              </div>
              <h1 className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                {product.name}
              </h1>

              {/* Rating */}
              <div className="mt-4 flex items-center gap-3">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating)
                          ? "fill-amber-400 text-amber-400"
                          : "fill-gray-200 text-gray-200"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {product.rating}
                </span>
                <span className="text-sm text-gray-500">
                  ({product.reviewCount.toLocaleString()} reviews)
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-bold text-gray-900">
                {formatPrice(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-xl text-gray-400 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
              {discount > 0 && (
                <Badge className="bg-green-50 text-green-700 border-green-200 text-sm font-semibold">
                  Save {formatPrice(product.originalPrice! - product.price)}
                </Badge>
              )}
            </div>

            {/* Description */}
            <p className="text-base leading-relaxed text-gray-600">
              {product.description}
            </p>

            {/* Colors */}
            {product.colors && (
              <div>
                <p className="text-sm font-semibold text-gray-900">Color</p>
                <div className="mt-2 flex gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all ${
                        selectedColor === color
                          ? "border-gray-900 ring-2 ring-gray-300 scale-110"
                          : "border-gray-200 hover:border-gray-400"
                      }`}
                      style={{ backgroundColor: color }}
                    >
                      {selectedColor === color && (
                        <Check className="h-4 w-4 text-white drop-shadow" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Features */}
            <div>
              <p className="text-sm font-semibold text-gray-900">
                Key Features
              </p>
              <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="h-4 w-4 flex-shrink-0 text-green-500" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Add to Cart Button */}
            <button
              onClick={() => addItem(product)}
              disabled={!product.inStock}
              className="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 px-8 py-4 text-base font-semibold text-white shadow-lg shadow-indigo-200/50 transition-all duration-200 hover:from-indigo-600 hover:to-purple-700 hover:shadow-xl hover:shadow-indigo-200/70 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
            >
              <ShoppingCart className="h-5 w-5" />
              {product.inStock ? "Add to Cart" : "Out of Stock"}
            </button>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 rounded-2xl border border-gray-100 bg-gray-50/50 p-4">
              <div className="text-center">
                <Truck className="mx-auto h-5 w-5 text-indigo-500" />
                <p className="mt-1.5 text-xs font-medium text-gray-700">
                  Free Shipping
                </p>
                <p className="text-xs text-gray-400">5-10 business days</p>
              </div>
              <div className="text-center">
                <Shield className="mx-auto h-5 w-5 text-indigo-500" />
                <p className="mt-1.5 text-xs font-medium text-gray-700">
                  Secure Checkout
                </p>
                <p className="text-xs text-gray-400">SSL encrypted</p>
              </div>
              <div className="text-center">
                <RotateCcw className="mx-auto h-5 w-5 text-indigo-500" />
                <p className="mt-1.5 text-xs font-medium text-gray-700">
                  30-Day Returns
                </p>
                <p className="text-xs text-gray-400">No questions asked</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="border-t border-gray-100 bg-gray-50/50 py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">
              You May Also Like
            </h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
